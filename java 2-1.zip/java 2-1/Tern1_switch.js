let a = Math.floor(Math.random() * 100);
let result;

switch (true) {
    case ((a > 10 ? a : a * 2) > 5):
        result = (2 * a) + 1;
        break;
    default:
        switch (true) {
            case (a < 3 ? 1 : 2 * (a - 2) > 4):
                result = 5;
                break;
            default:
                switch (a % 2 == 0) {
                    case true:
                        result = 6;
                        break;
                    default:
                        result = 7;
                }
        }
}

console.log(result);
// условие с условным (тернарным) оператором перевести в if...else И switch()
// результат выводить в консоль, с пощью console.log()