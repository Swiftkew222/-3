function manyChecks() {
  let a = Math.floor(Math.random() * 20) + 1;
  console.log(`a = ${a}`);
  let result;

  switch (true) {
    case (a > 10):
      result = 'a is bigger than 10';
      break;
    default:
      result = 'a is less than or equal to 10 ';
      switch (true) {
        case (a === 5):
          result += 'an example of a special case';
          break;
        default:
          break;
      }
  }

  if (a === 15) {
    result += 'but a is not 15';
  }

  switch (true) {
    case (a > 5):
      result += 'and a is greater than 5';
      break;
    default:
      result += 'and a is less than or equal to 5 ';
  }

  switch (true) {
    case (a % 2 !== 0):
      result += ' and a is odd';
      break;
    default:
      result += ' and a is even';
  }

  console.log(result);
}

// условие с условным (тернарным) оператором перевести в if...else И switch()
// результат выводить в консоль, с пощью console.log()