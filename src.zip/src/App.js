import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setUsers } from './features/usersSlice';
import { setPosts } from './features/postsSlice';

function App() {
  const dispatch = useDispatch();
  const users = useSelector((state) => state.users);
  const posts = useSelector((state) => state.posts);
  
  const [loading, setLoading] = useState(true);
  const [activeUserId, setActiveUserId] = useState(null);
  
  const USERS_URL = 'https://jsonplaceholder.typicode.com/users';
  const POSTS_URL = 'https://jsonplaceholder.typicode.com/posts';

  useEffect(() => {
    Promise.all([
      fetch(USERS_URL).then(res => res.json()),
      fetch(POSTS_URL).then(res => res.json())
    ]).then(([usersData, postsData]) => {
      dispatch(setUsers(usersData));
      dispatch(setPosts(postsData));
      setLoading(false);
    });
  }, [dispatch]);

  // Фильтрация постов по выбранному пользователю
  const filteredPosts = posts.filter(p => p.userId === activeUserId);

  return (
    <div style={{ display: 'flex', padding: '20px' }}>
      {/* Список пользователей */}
      <div style={{ width: '200px', marginRight: '20px' }}>
        <h3>Пользователи</h3>
        {loading ? (
          <p>Загрузка...</p>
        ) : (
          users.map(user => (
            <button
              key={user.id}
              style={{
                display: 'block',
                width: '100%',
                marginBottom: '10px',
                padding: '8px',
              }}
              onClick={() => setActiveUserId(user.id)}
            >
              {user.name}
            </button>
          ))
        )}
      </div>

      {/* Блок с постами */}
      <div style={{ flex: 1 }}>
        {activeUserId ? (
          <>
            <h3>Посты пользователя</h3>
            {filteredPosts.length === 0 ? (
              <p>Нет постов для этого пользователя.</p>
            ) : (
              filteredPosts.map(post => {
                const user = users.find(u => u.id === post.userId);
                return (
                  <div
                    key={post.id}
                    style={{
                      border: '1px solid #ccc',
                      borderRadius: '8px',
                      padding: '10px',
                      marginBottom: '10px',
                    }}
                  >
                    <h4>{user ? user.name : 'Пользователь'}</h4>
                    <h5>{post.title}</h5>
                    <p>{post.body}</p>
                  </div>
                );
              })
            )}
          </>
        ) : (
          <p>Выберите пользователя, чтобы увидеть его посты.</p>
        )}
      </div>
    </div>
  );
}

export default App;